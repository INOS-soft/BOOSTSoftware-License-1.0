export const getWindowState = jest.fn()
