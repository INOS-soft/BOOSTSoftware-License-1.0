export type LogLevel = 'error' | 'warn' | 'info' | 'debug'
